#encoding "utf8"

PP -> Prep Noun;
S -> Verb interp(Fact.Field1) PP;